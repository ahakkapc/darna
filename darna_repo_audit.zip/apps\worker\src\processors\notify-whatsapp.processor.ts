import { PrismaClient } from '@prisma/client';
import { withOrg } from './tenancy';

export async function processNotifyWhatsapp(
  prisma: PrismaClient,
  payload: { organizationId?: string; dispatchId?: string; requestId?: string },
): Promise<void> {
  const orgId = payload.organizationId;
  const dispatchId = payload.dispatchId;

  if (!orgId || !dispatchId) {
    console.log(`[NOTIFY_WHATSAPP] missing orgId or dispatchId — skip`);
    return;
  }

  await withOrg(prisma, orgId, async (tx) => {
    const dispatch = await tx.notificationDispatch.findFirst({
      where: { id: dispatchId, organizationId: orgId, channel: 'WHATSAPP' },
      include: { notification: true },
    });

    if (!dispatch) {
      console.log(`[NOTIFY_WHATSAPP] dispatch ${dispatchId} not found — skip`);
      return;
    }

    if (dispatch.state === 'SENT') {
      console.log(`[NOTIFY_WHATSAPP] dispatch ${dispatchId} already SENT — idempotent skip`);
      return;
    }

    if (dispatch.state !== 'PENDING') {
      console.log(`[NOTIFY_WHATSAPP] dispatch ${dispatchId} state=${dispatch.state} — skip`);
      return;
    }

    await tx.notificationDispatch.update({
      where: { id: dispatchId },
      data: { attempts: dispatch.attempts + 1 },
    });

    try {
      // MVP stub: log intent, no actual WhatsApp sending
      console.log(`[NOTIFY_WHATSAPP] stub — title="${dispatch.notification.title}" userId=${dispatch.notification.userId}`);

      await tx.notificationDispatch.update({
        where: { id: dispatchId },
        data: { state: 'SENT', sentAt: new Date() },
      });
    } catch (err: any) {
      const shouldRetry = dispatch.attempts + 1 < dispatch.maxAttempts;
      await tx.notificationDispatch.update({
        where: { id: dispatchId },
        data: {
          state: shouldRetry ? 'PENDING' : 'FAILED',
          lastErrorCode: err.code ?? 'UNKNOWN',
          lastErrorJson: { message: err.message } as any,
        },
      });
      if (!shouldRetry) {
        console.error(`[NOTIFY_WHATSAPP] dispatch ${dispatchId} FAILED after ${dispatch.attempts + 1} attempts`);
      }
      throw err;
    }
  });
}
