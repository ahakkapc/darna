-- AlterEnum
ALTER TYPE "SystemEventKind" ADD VALUE 'LEAD_DELETED';
