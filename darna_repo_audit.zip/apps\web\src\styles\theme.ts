'use client';

import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#070A0F',
      paper: '#0B1220',
    },
    text: {
      primary: '#EAF0F6',
      secondary: '#EAF0F6B3',
    },
    divider: 'rgba(255,255,255,0.08)',
    primary: {
      main: '#D8A24A',
      dark: '#B9822A',
    },
    secondary: {
      main: '#4DA3FF',
    },
    info: {
      main: '#7C5CFF',
    },
    success: {
      main: '#2ECC71',
    },
    warning: {
      main: '#F5A524',
    },
    error: {
      main: '#FF4D4F',
    },
  },
  typography: {
    fontFamily: '"Inter", sans-serif',
    h1: {
      fontSize: '22px',
      lineHeight: '30px',
      fontWeight: 700,
    },
    h2: {
      fontSize: '16px',
      lineHeight: '24px',
      fontWeight: 700,
    },
    body1: {
      fontSize: '14px',
      lineHeight: '20px',
      fontWeight: 400,
    },
    body2: {
      fontSize: '12px',
      lineHeight: '16px',
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: 12,
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          backgroundColor: 'var(--bg-0)',
          color: 'var(--text)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 'var(--radius-input)',
          height: 40,
          fontWeight: 600,
          fontSize: '14px',
        },
        containedPrimary: {
          background: 'var(--grad-brand)',
          color: 'var(--bg-0)',
          '&:hover': {
            background: 'var(--grad-brand)',
            opacity: 0.9,
          },
        },
        outlined: {
          borderColor: 'var(--line)',
          backgroundColor: 'transparent',
          '&:hover': {
            borderColor: 'rgba(216,162,74,0.45)',
            backgroundColor: 'transparent',
          },
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            backgroundColor: 'var(--bg-2)',
            borderRadius: 'var(--radius-input)',
            '& fieldset': {
              borderColor: 'var(--line)',
            },
            '&:hover fieldset': {
              borderColor: 'rgba(216,162,74,0.35)',
            },
            '&.Mui-focused fieldset': {
              borderColor: 'rgba(216,162,74,0.35)',
              boxShadow: '0 0 0 2px rgba(77,163,255,0.35)',
            },
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          background: 'var(--grad-surface), var(--bg-1)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--radius-card)',
          backgroundClip: 'padding-box',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 'var(--radius-pill)',
          backgroundColor: 'rgba(216,162,74,0.10)',
          border: '1px solid rgba(216,162,74,0.25)',
          color: 'var(--text)',
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          '&:hover': {
            backgroundColor: 'rgba(216,162,74,0.06)',
          },
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: 'var(--bg-1)',
          borderRadius: 'var(--radius-drawer)',
        },
      },
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          borderColor: 'var(--line)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
  },
});

export default theme;
