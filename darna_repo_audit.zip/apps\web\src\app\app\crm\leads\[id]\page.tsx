'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import CircularProgress from '@mui/material/CircularProgress';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Tooltip from '@mui/material/Tooltip';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import {
  Trash, PencilSimple, Trophy, XCircle, UserPlus,
  Note, Phone, MapPin, Clock, CaretDown,
  File as FileIcon, UploadSimple, CheckCircle,
} from '@phosphor-icons/react';
import DPage from '@/components/ui/DPage';
import DCard from '@/components/ui/DCard';
import DStatusBadge from '@/components/ui/DStatusBadge';
import DPriorityPill from '@/components/ui/DPriorityPill';
import DCursorLoadMore from '@/components/ui/DCursorLoadMore';
import DDateTimePicker from '@/components/ui/DDateTimePicker';
import { DErrorState, DNotFoundState } from '@/components/ui/DStates';
import { useToast } from '@/components/ui/DToast';
import { http, ApiError } from '@/lib/http';

interface Lead {
  id: string;
  fullName: string;
  phone: string | null;
  email: string | null;
  status: string;
  priority: string;
  type: string;
  ownerUserId: string | null;
  wilaya: string | null;
  commune: string | null;
  quartier: string | null;
  budgetMin: number | null;
  budgetMax: number | null;
  propertyType: string | null;
  surfaceMin: number | null;
  notes: string | null;
  tagsJson: string[] | null;
  nextActionAt: string | null;
  createdAt: string;
  updatedAt: string;
  relations?: { id: string; type: string; targetLeadId: string }[];
}

interface Activity {
  id: string;
  type: string;
  title: string | null;
  body: string | null;
  createdAt: string;
  createdByUserId: string;
  happenedAt: string | null;
  payloadJson: Record<string, unknown> | null;
}

interface Task {
  id: string;
  title: string;
  status: string;
  priority: string;
  dueAt: string | null;
  assigneeUserId: string | null;
  completedAt: string | null;
}

interface Doc {
  id: string;
  title: string;
  kind: string;
  createdAt: string;
}

export default function LeadDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { toast } = useToast();

  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);

  const fetchLead = useCallback(async () => {
    setLoading(true);
    try {
      const res = await http.get<Lead>(`/crm/leads/${id}`);
      setLead(res);
      setError(null);
    } catch (e) {
      if (e instanceof ApiError) setError(e);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { fetchLead(); }, [fetchLead]);

  const handleMarkWon = async () => {
    try {
      await http.post(`/crm/leads/${id}/mark-won`, {});
      toast('Lead marqué comme gagné', 'success');
      fetchLead();
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  const handleMarkLost = async () => {
    try {
      await http.post(`/crm/leads/${id}/mark-lost`, { lostReason: 'Perdu' });
      toast('Lead marqué comme perdu', 'info');
      fetchLead();
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  const handleDelete = async () => {
    try {
      await http.delete(`/crm/leads/${id}`);
      toast('Lead supprimé', 'info');
      router.push('/app/crm/leads');
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 'var(--space-32)' }}><CircularProgress /></Box>;
  if (error?.status === 404 || !lead) return <DNotFoundState cta={{ label: 'Retour', onClick: () => router.push('/app/crm/leads') }} />;
  if (error?.status === 403) return <DPage title="Lead"><Box><Typography>Accès interdit</Typography></Box></DPage>;
  if (error) return <DErrorState requestId={error.requestId} cta={{ label: 'Réessayer', onClick: fetchLead }} />;

  return (
    <DPage
      title={lead.fullName}
      actions={
        <Box sx={{ display: 'flex', gap: 'var(--space-8)', flexWrap: 'wrap' }}>
          <DStatusBadge status={lead.status} />
          <DPriorityPill priority={lead.priority} />
          <Button size="small" variant="outlined" startIcon={<Trophy size={14} />} onClick={handleMarkWon}>Gagné</Button>
          <Button size="small" variant="outlined" startIcon={<XCircle size={14} />} onClick={handleMarkLost}>Perdu</Button>
          <IconButton size="small" onClick={handleDelete} sx={{ color: 'var(--danger)' }}><Trash size={18} /></IconButton>
        </Box>
      }
    >
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 380px' }, gap: 'var(--space-24)' }}>
        {/* Main */}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-24)' }}>
          <TimelineSection leadId={id} />
          <TasksSection leadId={id} />
          <DocumentsSection leadId={id} />
        </Box>

        {/* Sidebar */}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-16)' }}>
          <ContactCard lead={lead} />
          <CriteriaCard lead={lead} />
          <TagsCard tags={lead.tagsJson ?? []} />
          <NextActionCard leadId={id} value={lead.nextActionAt} onUpdate={fetchLead} />
        </Box>
      </Box>
    </DPage>
  );
}

/* ─── TIMELINE ─────────────────────────────────────── */
function TimelineSection({ leadId }: { leadId: string }) {
  const { toast } = useToast();
  const [tab, setTab] = useState(0);
  const [items, setItems] = useState<Activity[]>([]);
  const [cursor, setCursor] = useState<string | undefined>();
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const typeFilter = ['', 'NOTE', 'CALL', 'VISIT'][tab] ?? '';

  const fetchActivities = useCallback(async (reset?: boolean) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('limit', '10');
      if (typeFilter) params.set('type', typeFilter);
      if (!reset && cursor) params.set('cursor', cursor);
      const res = await http.get<{ items: Activity[]; page: { hasMore: boolean; nextCursor?: string } }>(
        `/crm/leads/${leadId}/activities?${params}`,
      );
      setItems(reset ? res.items : (p) => [...p, ...res.items]);
      setCursor(res.page.nextCursor);
      setHasMore(res.page.hasMore);
    } catch { /* silent */ } finally { setLoading(false); }
  }, [leadId, typeFilter, cursor]);

  useEffect(() => { setCursor(undefined); fetchActivities(true); }, [leadId, typeFilter]);

  const [noteText, setNoteText] = useState('');
  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    try {
      await http.post(`/crm/leads/${leadId}/activities`, { type: 'NOTE', body: noteText });
      setNoteText('');
      toast('Note ajoutée', 'success');
      setCursor(undefined);
      fetchActivities(true);
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  return (
    <DCard title="Timeline">
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 'var(--space-16)', minHeight: 36, '& .MuiTab-root': { minHeight: 36, fontSize: '13px', textTransform: 'none' } }}>
        <Tab label="Tous" />
        <Tab label="Notes" />
        <Tab label="Appels" />
        <Tab label="Visites" />
      </Tabs>

      {/* Composer: Note */}
      <Box sx={{ display: 'flex', gap: 'var(--space-8)', mb: 'var(--space-16)' }}>
        <TextField
          size="small"
          fullWidth
          placeholder="Ajouter une note…"
          value={noteText}
          onChange={(e) => setNoteText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleAddNote(); } }}
        />
        <Button variant="contained" size="small" onClick={handleAddNote} disabled={!noteText.trim()}>
          <Note size={16} />
        </Button>
      </Box>

      {/* Items */}
      {items.map((a) => (
        <Box key={a.id} sx={{ display: 'flex', gap: 'var(--space-12)', py: 'var(--space-12)', borderBottom: '1px solid var(--line)' }}>
          <Box sx={{ color: 'var(--muted)', mt: '2px' }}>
            {a.type === 'CALL' ? <Phone size={18} weight="duotone" /> :
             a.type === 'VISIT' ? <MapPin size={18} weight="duotone" /> :
             a.type === 'SYSTEM_EVENT' ? <Clock size={18} weight="duotone" /> :
             <Note size={18} weight="duotone" />}
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontSize: '13px', fontWeight: 600 }}>
              {a.title ?? a.type}
              <Typography component="span" sx={{ color: 'var(--muted-2)', fontSize: '11px', ml: 'var(--space-8)' }}>
                {new Date(a.createdAt).toLocaleString('fr-FR')}
              </Typography>
            </Typography>
            {a.body && <Typography sx={{ color: 'var(--muted)', fontSize: '13px', mt: '2px' }}>{a.body}</Typography>}
          </Box>
        </Box>
      ))}
      {!loading && items.length === 0 && (
        <Typography sx={{ color: 'var(--muted-2)', py: 'var(--space-16)', textAlign: 'center', fontSize: '13px' }}>
          Aucune activité
        </Typography>
      )}
      <DCursorLoadMore hasMore={hasMore} loading={loading} onLoadMore={() => fetchActivities()} />
    </DCard>
  );
}

/* ─── TASKS ────────────────────────────────────────── */
function TasksSection({ leadId }: { leadId: string }) {
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [dueAt, setDueAt] = useState('');
  const [priority, setPriority] = useState('MEDIUM');

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const res = await http.get<{ items: Task[] }>(`/crm/tasks?scope=lead:${leadId}&limit=50`);
      setTasks(res.items);
    } catch { /* silent */ } finally { setLoading(false); }
  }, [leadId]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const handleAdd = async () => {
    if (!title.trim()) return;
    try {
      const body: Record<string, unknown> = { title, priority };
      if (dueAt) body.dueAt = dueAt;
      await http.post(`/crm/leads/${leadId}/tasks`, body);
      setTitle('');
      setDueAt('');
      toast('Tâche créée', 'success');
      fetchTasks();
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  const toggleDone = async (task: Task) => {
    try {
      const newStatus = task.status === 'DONE' ? 'OPEN' : 'DONE';
      await http.patch(`/crm/tasks/${task.id}`, { status: newStatus });
      fetchTasks();
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  return (
    <DCard title="Tâches">
      {/* Quick add */}
      <Box sx={{ display: 'flex', gap: 'var(--space-8)', mb: 'var(--space-16)', flexWrap: 'wrap' }}>
        <TextField size="small" placeholder="Nouvelle tâche…" value={title} onChange={(e) => setTitle(e.target.value)} sx={{ flex: 1, minWidth: 200 }} />
        <Box sx={{ width: 160 }}>
          <DDateTimePicker value={dueAt} onChange={setDueAt} label="Échéance" />
        </Box>
        <Select size="small" value={priority} onChange={(e) => setPriority(e.target.value)} sx={{ minWidth: 90, fontSize: '13px' }}>
          <MenuItem value="LOW">Low</MenuItem>
          <MenuItem value="MEDIUM">Medium</MenuItem>
          <MenuItem value="HIGH">High</MenuItem>
          <MenuItem value="URGENT">Urgent</MenuItem>
        </Select>
        <Button variant="contained" size="small" onClick={handleAdd} disabled={!title.trim()}>Ajouter</Button>
      </Box>

      {/* List */}
      {tasks.map((t) => {
        const overdue = t.dueAt && new Date(t.dueAt) < new Date() && t.status !== 'DONE';
        return (
          <Box
            key={t.id}
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 'var(--space-8)',
              py: 'var(--space-8)',
              borderBottom: '1px solid var(--line)',
              ...(overdue ? { backgroundColor: 'rgba(255,77,79,0.04)' } : {}),
            }}
          >
            <Checkbox
              size="small"
              checked={t.status === 'DONE'}
              onChange={() => toggleDone(t)}
              sx={{ color: 'var(--muted)', '&.Mui-checked': { color: 'var(--success)' } }}
            />
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: '13px', textDecoration: t.status === 'DONE' ? 'line-through' : 'none', color: t.status === 'DONE' ? 'var(--muted-2)' : 'var(--text)' }}>
                {t.title}
              </Typography>
              {t.dueAt && (
                <Typography sx={{ fontSize: '11px', color: overdue ? 'var(--danger)' : 'var(--muted-2)' }}>
                  {new Date(t.dueAt).toLocaleString('fr-FR')}
                </Typography>
              )}
            </Box>
            <DPriorityPill priority={t.priority} />
          </Box>
        );
      })}
      {!loading && tasks.length === 0 && (
        <Typography sx={{ color: 'var(--muted-2)', py: 'var(--space-16)', textAlign: 'center', fontSize: '13px' }}>
          Aucune tâche
        </Typography>
      )}
    </DCard>
  );
}

/* ─── DOCUMENTS ────────────────────────────────────── */
interface DocLink {
  id: string;
  document: { id: string; title: string; kind: string; status: string };
  createdAt: string;
}

function DocumentsSection({ leadId }: { leadId: string }) {
  const { toast } = useToast();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [docs, setDocs] = useState<Doc[]>([]);
  const [docsLoading, setDocsLoading] = useState(true);
  const [docsError, setDocsError] = useState<ApiError | null>(null);

  const fetchDocs = useCallback(async () => {
    setDocsLoading(true);
    setDocsError(null);
    try {
      const links = await http.get<DocLink[]>(`/crm/leads/${leadId}/documents`);
      setDocs(
        links
          .filter((l) => l.document.status === 'ACTIVE')
          .map((l) => ({
            id: l.document.id,
            title: l.document.title,
            kind: l.document.kind,
            createdAt: l.createdAt,
          })),
      );
    } catch (e) {
      if (e instanceof ApiError) setDocsError(e);
    } finally {
      setDocsLoading(false);
    }
  }, [leadId]);

  useEffect(() => { fetchDocs(); }, [fetchDocs]);

  const handleUpload = async (file: File) => {
    setUploading(true);
    try {
      // Step 1: Presign
      const presign = await http.post<{ sessionId: string; url: string; storageKey: string }>('/storage/upload/presign', {
        mimeType: file.type,
        sizeBytes: file.size,
        originalFilename: file.name,
      });

      // Step 2: Upload to presigned URL
      await fetch(presign.url, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });

      // Step 3: Confirm
      await http.post('/storage/upload/confirm', {
        sessionId: presign.sessionId,
        document: { title: file.name },
        link: { targetType: 'LEAD', targetId: leadId },
      });

      toast('Document uploadé', 'success');
      setUploadOpen(false);
      fetchDocs();
    } catch (e) {
      if (e instanceof ApiError) toast(e.message, 'error');
      else toast('Erreur upload', 'error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <DCard title="Documents" actions={
      <Button size="small" variant="outlined" startIcon={<UploadSimple size={14} />} onClick={() => setUploadOpen(true)}>
        Upload
      </Button>
    }>
      {docsLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 'var(--space-16)' }}><CircularProgress size={24} /></Box>}
      {docsError && <DErrorState requestId={docsError.requestId} cta={{ label: 'Réessayer', onClick: fetchDocs }} />}
      {!docsLoading && !docsError && docs.length === 0 && (
        <Typography sx={{ color: 'var(--muted-2)', py: 'var(--space-16)', textAlign: 'center', fontSize: '13px' }}>
          Aucun document attaché
        </Typography>
      )}
      {docs.map((d) => (
        <Box key={d.id} sx={{ display: 'flex', alignItems: 'center', gap: 'var(--space-12)', py: 'var(--space-8)', borderBottom: '1px solid var(--line)' }}>
          <FileIcon size={20} weight="duotone" style={{ color: 'var(--muted)' }} />
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontSize: '13px' }}>{d.title}</Typography>
            <Typography sx={{ fontSize: '11px', color: 'var(--muted-2)' }}>{d.kind} · {new Date(d.createdAt).toLocaleDateString('fr-FR')}</Typography>
          </Box>
        </Box>
      ))}

      {/* Upload dialog */}
      <Dialog open={uploadOpen} onClose={() => !uploading && setUploadOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Upload un document</DialogTitle>
        <DialogContent>
          <Box
            sx={{
              border: '2px dashed var(--line)',
              borderRadius: 'var(--radius-card)',
              p: 'var(--space-32)',
              textAlign: 'center',
              cursor: uploading ? 'default' : 'pointer',
            }}
            onClick={() => {
              if (uploading) return;
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = 'image/*,.pdf';
              input.onchange = (e) => {
                const f = (e.target as HTMLInputElement).files?.[0];
                if (f) handleUpload(f);
              };
              input.click();
            }}
          >
            {uploading ? (
              <CircularProgress size={32} />
            ) : (
              <>
                <UploadSimple size={32} weight="duotone" style={{ color: 'var(--muted)' }} />
                <Typography sx={{ color: 'var(--muted)', mt: 'var(--space-8)' }}>
                  Cliquez pour sélectionner un fichier
                </Typography>
              </>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUploadOpen(false)} disabled={uploading}>Annuler</Button>
        </DialogActions>
      </Dialog>
    </DCard>
  );
}

/* ─── SIDEBAR CARDS ────────────────────────────────── */
function ContactCard({ lead }: { lead: Lead }) {
  return (
    <DCard title="Contact">
      <InfoRow label="Téléphone" value={lead.phone ?? '—'} />
      <InfoRow label="Email" value={lead.email ?? '—'} />
      <InfoRow label="Type" value={lead.type} />
      <InfoRow label="Créé le" value={new Date(lead.createdAt).toLocaleDateString('fr-FR')} />
    </DCard>
  );
}

function CriteriaCard({ lead }: { lead: Lead }) {
  const fmt = (n: number | null) => n != null ? `${n.toLocaleString('fr-FR')} DA` : '—';
  return (
    <DCard title="Critères">
      <InfoRow label="Budget" value={`${fmt(lead.budgetMin)} — ${fmt(lead.budgetMax)}`} />
      <InfoRow label="Wilaya" value={lead.wilaya ?? '—'} />
      <InfoRow label="Commune" value={lead.commune ?? '—'} />
      <InfoRow label="Quartier" value={lead.quartier ?? '—'} />
      <InfoRow label="Type de bien" value={lead.propertyType ?? '—'} />
      <InfoRow label="Surface min" value={lead.surfaceMin ? `${lead.surfaceMin} m²` : '—'} />
    </DCard>
  );
}

function TagsCard({ tags }: { tags: string[] }) {
  return (
    <DCard title="Tags">
      {tags.length === 0 ? (
        <Typography sx={{ color: 'var(--muted-2)', fontSize: '13px' }}>Aucun tag</Typography>
      ) : (
        <Box sx={{ display: 'flex', gap: 'var(--space-4)', flexWrap: 'wrap' }}>
          {tags.map((t) => <Chip key={t} label={t} size="small" />)}
        </Box>
      )}
    </DCard>
  );
}

function NextActionCard({ leadId, value, onUpdate }: { leadId: string; value: string | null; onUpdate: () => void }) {
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [dateVal, setDateVal] = useState(value ?? '');

  const save = async () => {
    try {
      await http.patch(`/crm/leads/${leadId}`, { nextActionAt: dateVal || null });
      toast('Prochaine action mise à jour', 'success');
      setEditing(false);
      onUpdate();
    } catch (e) { if (e instanceof ApiError) toast(e.message, 'error'); }
  };

  return (
    <DCard title="Prochaine action" actions={!editing ? <Button size="small" onClick={() => setEditing(true)} sx={{ fontSize: '12px' }}>Modifier</Button> : undefined}>
      {editing ? (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-8)' }}>
          <DDateTimePicker value={dateVal} onChange={setDateVal} />
          <Box sx={{ display: 'flex', gap: 'var(--space-8)' }}>
            <Button size="small" variant="contained" onClick={save}>Sauver</Button>
            <Button size="small" variant="text" onClick={() => setEditing(false)}>Annuler</Button>
          </Box>
        </Box>
      ) : (
        <Typography sx={{ color: value ? 'var(--text)' : 'var(--muted-2)', fontSize: '14px' }}>
          {value ? new Date(value).toLocaleString('fr-FR') : 'Non définie'}
        </Typography>
      )}
    </DCard>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', py: 'var(--space-4)' }}>
      <Typography sx={{ color: 'var(--muted)', fontSize: '13px' }}>{label}</Typography>
      <Typography sx={{ fontSize: '13px', fontVariantNumeric: 'tabular-nums' }}>{value}</Typography>
    </Box>
  );
}
