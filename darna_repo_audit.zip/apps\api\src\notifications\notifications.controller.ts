import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Query,
  Body,
  UseGuards,
  ParseUUIDPipe,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { OrgContextGuard } from '../tenancy/org-context.guard';
import { CurrentUser, CurrentUserPayload } from '../auth/current-user.decorator';
import { OrgId } from '../tenancy/org-context.decorator';
import { NotificationService } from './notification.service';
import { ListNotificationsDto } from './dto/list-notifications.dto';
import { ReadAllDto } from './dto/read-all.dto';

@Controller('notifications')
@UseGuards(JwtAuthGuard, OrgContextGuard)
export class NotificationsController {
  constructor(private readonly notificationService: NotificationService) {}

  @Get()
  list(
    @CurrentUser() user: CurrentUserPayload,
    @OrgId() orgId: string,
    @Query() query: ListNotificationsDto,
  ) {
    return this.notificationService.list(orgId, user.userId, {
      unreadOnly: query.unreadOnly,
      category: query.category,
      limit: query.limit,
      cursor: query.cursor,
    });
  }

  @Get('unread-count')
  async unreadCount(
    @CurrentUser() user: CurrentUserPayload,
    @OrgId() orgId: string,
  ) {
    const count = await this.notificationService.unreadCount(orgId, user.userId);
    return { count };
  }

  @Post(':id/read')
  markRead(
    @CurrentUser() user: CurrentUserPayload,
    @OrgId() orgId: string,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.notificationService.markRead(orgId, user.userId, id);
  }

  @Post('read-all')
  markReadAll(
    @CurrentUser() user: CurrentUserPayload,
    @OrgId() orgId: string,
    @Body() dto: ReadAllDto,
  ) {
    return this.notificationService.markReadAll(orgId, user.userId, dto.category);
  }

  @Delete(':id')
  softDelete(
    @CurrentUser() user: CurrentUserPayload,
    @OrgId() orgId: string,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.notificationService.softDelete(orgId, user.userId, id);
  }
}
