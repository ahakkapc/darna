export type TemplateContext = {
  orgId: string;
  userId: string;
  meta: Record<string, unknown>;
};

export type RenderedNotification = {
  title: string;
  body?: string;
  linkUrl?: string;
  priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
};

type TemplateRenderer = (ctx: TemplateContext) => RenderedNotification;

const templates: Record<string, TemplateRenderer> = {
  'lead.new': (ctx) => ({
    title: 'Nouveau lead reçu',
    body: ctx.meta.leadName ? `Lead : ${String(ctx.meta.leadName).slice(0, 80)}` : undefined,
    linkUrl: ctx.meta.leadId ? `/app/crm/leads/${ctx.meta.leadId}` : undefined,
    priority: 'HIGH',
  }),

  'lead.assigned': (ctx) => ({
    title: "Un lead t'a été assigné",
    body: ctx.meta.leadName ? `Lead : ${String(ctx.meta.leadName).slice(0, 80)}` : undefined,
    linkUrl: ctx.meta.leadId ? `/app/crm/leads/${ctx.meta.leadId}` : undefined,
    priority: 'HIGH',
  }),

  'lead.status.changed': (ctx) => ({
    title: `Lead passé en ${ctx.meta.newStatus ?? 'nouveau statut'}`,
    linkUrl: ctx.meta.leadId ? `/app/crm/leads/${ctx.meta.leadId}` : undefined,
    priority: 'NORMAL',
  }),

  'task.assigned': (ctx) => ({
    title: "Une tâche t'a été assignée",
    body: ctx.meta.taskTitle ? String(ctx.meta.taskTitle).slice(0, 120) : undefined,
    linkUrl: ctx.meta.taskId ? `/app/crm/tasks/${ctx.meta.taskId}` : undefined,
    priority: 'HIGH',
  }),

  'task.reminder': (ctx) => ({
    title: 'Rappel : tâche à traiter',
    body: ctx.meta.taskTitle ? String(ctx.meta.taskTitle).slice(0, 120) : undefined,
    linkUrl: ctx.meta.taskId ? `/app/crm/tasks/${ctx.meta.taskId}` : undefined,
    priority: 'HIGH',
  }),

  'task.overdue': (ctx) => ({
    title: 'Tâche en retard',
    body: ctx.meta.taskTitle ? String(ctx.meta.taskTitle).slice(0, 120) : undefined,
    linkUrl: ctx.meta.taskId ? `/app/crm/tasks/${ctx.meta.taskId}` : undefined,
    priority: 'URGENT',
  }),

  'listing.submitted': () => ({
    title: 'Nouvelle annonce soumise pour modération',
    priority: 'NORMAL',
  }),

  'listing.approved': (ctx) => ({
    title: 'Annonce approuvée',
    linkUrl: ctx.meta.listingId ? `/app/listings/${ctx.meta.listingId}` : undefined,
    priority: 'NORMAL',
  }),

  'listing.rejected': (ctx) => ({
    title: 'Annonce refusée',
    body: ctx.meta.reason ? String(ctx.meta.reason).slice(0, 200) : undefined,
    linkUrl: ctx.meta.listingId ? `/app/listings/${ctx.meta.listingId}` : undefined,
    priority: 'HIGH',
  }),

  'inbox.new.message': (ctx) => ({
    title: 'Nouveau message reçu',
    linkUrl: ctx.meta.threadId ? `/app/inbox/${ctx.meta.threadId}` : undefined,
    priority: 'HIGH',
  }),

  'inbox.sla.breached': (ctx) => ({
    title: 'SLA dépassé sur un fil de discussion',
    linkUrl: ctx.meta.threadId ? `/app/inbox/${ctx.meta.threadId}` : undefined,
    priority: 'URGENT',
  }),

  'inbox.thread.assigned': (ctx) => ({
    title: "Un fil de discussion t'a été assigné",
    linkUrl: ctx.meta.threadId ? `/app/inbox/${ctx.meta.threadId}` : undefined,
    priority: 'HIGH',
  }),

  'billing.past_due': () => ({
    title: 'Paiement en retard',
    linkUrl: '/app/settings/billing',
    priority: 'URGENT',
  }),

  'billing.quota_reached': () => ({
    title: 'Quota atteint',
    linkUrl: '/app/settings/billing',
    priority: 'HIGH',
  }),

  'billing.period_ending': () => ({
    title: "Votre période d'abonnement se termine bientôt",
    linkUrl: '/app/settings/billing',
    priority: 'NORMAL',
  }),

  'kyc.submitted': () => ({
    title: 'KYC soumis — en cours de vérification',
    linkUrl: '/app/settings/kyc',
    priority: 'NORMAL',
  }),

  'kyc.approved': () => ({
    title: 'KYC approuvé',
    linkUrl: '/app/settings/kyc',
    priority: 'NORMAL',
  }),

  'kyc.rejected': (ctx) => ({
    title: 'KYC refusé',
    body: ctx.meta.reason ? String(ctx.meta.reason).slice(0, 200) : undefined,
    linkUrl: '/app/settings/kyc',
    priority: 'HIGH',
  }),
};

const MAX_TITLE = 120;
const MAX_BODY = 500;

export function renderTemplate(
  templateKey: string,
  ctx: TemplateContext,
): RenderedNotification | null {
  const renderer = templates[templateKey];
  if (!renderer) return null;

  const result = renderer(ctx);
  result.title = result.title.slice(0, MAX_TITLE);
  if (result.body) result.body = result.body.slice(0, MAX_BODY);
  return result;
}

export function isValidTemplateKey(key: string): boolean {
  return key in templates;
}
