GRANT SELECT, INSERT, UPDATE, DELETE ON "kyc_requests" TO darna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON "subscriptions" TO darna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON "offline_payments" TO darna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON "listings" TO darna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON "listing_moderations" TO darna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON "listing_lead_relations" TO darna_app;